x = int(input())
a = 1
b = 1
for i in range(0, x):
    print("number:",i , "  ", a)
    c  = a
    a = a + b
    b = c

    
